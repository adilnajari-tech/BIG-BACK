<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" type="text/css" href="style.css">
	<link rel="icon" href="img/icon.png">
     <title>BIG BACK | Sign Up</title>
</head>
<body>
<header>
	<nav>
		<h1>BIG <span>BACK</span></h1>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="login.php">Login</a></li>
			<li><a href="signup.php">Sign Up</a></li>
		</ul>
	</nav>
</header>
<div class="main-box">
	<h2 id="box-title">Sign Up From</h2>
	<hr>
	<form class="main-input" action="" method="post">
		<input type="text" name="name" placeholder="Username.."><br><br>
		<input type="Password" name="password" placeholder="Password.."><br>
		<input type="submit" name="" value="Sign Up">
		<a href="login.php"><button id="btn">Login</button></a>
		
	</form>
</div>
</body>
</html>