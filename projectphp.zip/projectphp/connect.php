<?php 

$serbername = "localhost";
$username = "root";
$password = "";
$dbname = "rojectphp";

$conn = mysql_connect( erbername, $username, $password, $dbname);

if (isset($conn)) {
	echo "DATABASE IS CONNECTED";
}
else{
	echo "NO CONNECTED !!";
}



 ?>