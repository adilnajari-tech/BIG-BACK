<?php  
include ('../connect.php');
if (isset($_POST['login'])) {
	
	$user = $_POST['user'];
	$pass = $_POST['pass'];

	$q1 = "SELECT * FROM user WHERE name = '$user' AND password = '$pass'";

	$data = mysqli_query($conn,$q1) or die ("ERROR IN q1");
	$row = mysqli_fetch_assoc($data);

	}
?>