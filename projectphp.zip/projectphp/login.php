<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" type="text/css" href="style.css">
	<link rel="icon" href="img/icon.png">
     <title>BIG BACK | Login</title>
</head>
<body>
<header>
	<nav>
		<h1>BIG <span>BACK</span></h1>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="login.php">Login</a></li>
			<li><a href="signup.php">Sign Up</a></li>
		</ul>
	</nav>
</header>
<div class="main-box">
	<h2 id="box-title">Login From</h2>
	<hr>
	<form class="main-input" action="add/login.php" method="post">
		<input type="text" name="user" placeholder="Username.."><br><br>
		<input type="Password" name="pass" placeholder="Password.."><br>
		<input type="submit" name="login" value="Login">
		<a href="signup.php"><button id="btn">Creat Acount</button></a>
		
	</form>
</div>
</body>
</html>