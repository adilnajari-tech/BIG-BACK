<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>BIG BACK</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="icon" href="img/icon.png">
</head>
<body>
<header>
	<nav>
		<h1>BIG <span>BACK</span></h1>
		<ul>
			<li><a href="#">Home</a></li>
			<li><a href="login.php">Login</a></li>
			<li><a href="signup.php">Sign Up</a></li>
		</ul>
	</nav>
</header>
<section class="backimg">
<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<h2 id="cenn">Welcome To BIG BACK</h2>
<hr id="carr">
<br>
<div id="main-btn">
<a href="signup.php"><button class="btn">Sign Up</button></a>
<a href="login.php"><button class="btn">Login</button></a>	
</div>
</section>
</body>
</html>